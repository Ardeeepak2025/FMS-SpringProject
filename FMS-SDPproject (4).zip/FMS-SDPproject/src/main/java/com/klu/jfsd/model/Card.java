package com.klu.jfsd.model;

public class Card {

}
